//Part 1 : User Data Array Manipulation 

//Creating 'users' array containing 15 objects 

let users = [
    {
      name: "Aarav Patel",
      age: 28,
      gender: "Male",
      location: "Mumbai, Maharashtra",
    },
    {
      name: "Ishita Sharma",
      age: 24,
      gender: "Female",
      location: "Delhi",
    },
    {
      name: "Vikram Singh",
      age: 12,
      gender: "Male",
      location: "Bangalore, Karnataka",
    },
    {
      name: "Kavita Mishra",
      age: 30,
      gender: "Female",
      location: "Lucknow, Uttar Pradesh",
    },
    {
      name: "Rahul Gupta",
      age: 15,
      gender: "Male",
      location: "Jaipur, Rajasthan",
    },
    {
      name: "Ananya Verma",
      age: 26,
      gender: "Female",
      location: "Hyderabad, Telangana",
    },
    {
      name: "Amit Joshi",
      age: 40,
      gender: "Male",
      location: "Ahmedabad, Gujarat",
    },
    {
      name: "Neha Yadav",
      age: 22,
      gender: "Female",
      location: "Chennai, Tamil Nadu",
    },
    {
      name: "Aditya Shukla",
      age: 16,
      gender: "Male",
      location: "Kolkata, West Bengal",
    },
    {
      name: "Pooja Rathore",
      age: 27,
      gender: "Female",
      location: "Bhopal, Madhya Pradesh",
    },
    {
      name: "Siddharth Reddy",
      age: 33,
      gender: "Male",
      location: "Pune, Maharashtra",
    },
    {
      name: "Meera Kapoor",
      age: 17,
      gender: "Female",
      location: "Coimbatore, Tamil Nadu",
    },
    {
      name: "Rohan Khanna",
      age: 34,
      gender: "Male",
      location: "Chandigarh",
    },
    {
      name: "Deepika Sharma",
      age: 25,
      gender: "Female",
      location: "Nagpur, Maharashtra",
    },
    {
      name: "Arjun Singh",
      age: 28,
      gender: "Male",
      location: "Indore, Madhya Pradesh",
    },
  ];
  
  console.log(users);
  
  //3.Implementing isAdult function
  isAdult=(user)=>{
    return user.age>=18;   
  }
//   console.log(isAdult(users[0]));
//4. Using the filter function for creating a new array 'adultUsers' by selecting only the users who are adults using isAdult function

let adultUsers = users.filter((user)=>{
    return isAdult(user);
})
console.log(adultUsers);

//5. Implementing a function 'getFullName' that takes a user object as input and returns the user's full name (combing 'name' and 'location' properties)

getFullName=(user)=>{
    return(user.name + " : "+ user.location) ;
}

// console.log(getFullName(users[0]));

//6. Use the map function to create a new array 'userNames' containing the full names of all users

let userNames=users.map((user)=>{
    return user.name;
});
console.log(userNames);

//Part 2: Chaining User Data Operations :

//1. Implement a function 'filterByGender' that takes a user object as input and a gender string as input and returns 'true' if the user's gender matches the input gender , otherwise false.

filterByGender=(user,Gender)=>{
    return user.gender === Gender;
}
// let Gender ="Male";
// console.log(filterByGender(users[0],Gender));

//2.a. Filter and create a new array 'femaleUsers' containing female users using the 'filterByGender' function

let femaleUsers =users.filter((user)=>{
    let Gender ="Female";
    return(filterByGender(user,Gender));
})
console.log(femaleUsers);

//3. Use the 'map' function to apply the 'getFullName' function to each element of the 'femaleUsers' array 

let femaleFullname=femaleUsers.map((user)=>{
    return getFullName(user);
});
console.log(femaleFullname);

//Part 3 : Movie Data Array Manipulation >>

//1. Defining an array 'movies' containing at least 10 objects with the properties title,genre,year,rating

let movies = [
    {
      title: "Inception",
      genre: "Sci-Fi",
      year: 2010,
      rating: 8.8,
    },
    {
      title: "The Dark Knight",
      genre: "Action",
      year: 2008,
      rating: 9.0,
    },
    {
      title: "Shawshank Redemption",
      genre: "Drama",
      year: 1994,
      rating: 9.3,
    },
    {
      title: "Pulp Fiction",
      genre: "Crime",
      year: 1994,
      rating: 8.9,
    },
    {
      title: "Forrest Gump",
      genre: "Drama",
      year: 1994,
      rating: 8.8,
    },
    {
      title: "The Matrix",
      genre: "Sci-Fi",
      year: 1999,
      rating: 8.7,
    },
    {
      title: "The Godfather",
      genre: "Crime",
      year: 1972,
      rating: 9.2,
    },
    {
      title: "Interstellar",
      genre: "Sci-Fi",
      year: 2014,
      rating: 8.6,
    },
    {
      title: "The Shawshank Redemption",
      genre: "Drama",
      year: 1994,
      rating: 9.3,
    },
    {
      title: "The Silence of the Lambs",
      genre: "Thriller",
      year: 1991,
      rating: 8.6,
    },
    {
        title: "Die Hard",
        genre: "Action",
        year: 1988,
        rating: 8.2,
      },
      {
        title: "Mad Max: Fury Road",
        genre: "Action",
        year: 2015,
        rating: 8.1,
      },
      {
        title: "The Terminator",
        genre: "Action",
        year: 1984,
        rating: 8.0,
      },
      {
        title: "John Wick",
        genre: "Action",
        year: 2014,
        rating: 7.4,
      },
      {
        title: "Gladiator",
        genre: "Action",
        year: 2000,
        rating: 8.5,
      },
  ];
  
  console.log(movies);

  //Part 4 : Chaining Movie Data Operations >>
  // 1. Implement a function 'filterByGenre' that takes a movie object as input and a genre string and returns 'true' or 'false' accordingly

  filterByGenre=(movie,Genre)=>{
    return(movie.genre===Genre);
  }
//   let Genre='Sci-Fi';
//   console.log(filterByGenre(movies[0],Genre))
//2.Use Chaining to manipulate the 'movies array in the following sequence

//a. Filter and create a new array 'actionMovies' containing movies with the "action" genre using 'filterByGenre' function
  let actionMovies= movies.filter((movie)=>{
    return(filterByGenre(movie,"Action"));
  });
  console.log(actionMovies);

  //b.Use the map function to create a new array 'movieTitles' containing the titles of all movies in 'actionMovies'

  let movieTitles = actionMovies.map((movie)=>{
    return movie.title;
  });
  console.log(movieTitles);


  //Part 5 : Integration and Output 

  let combinedResults ={
    Part1:[adultUsers,userNames],
    Part2:[femaleUsers,femaleFullname],
    Part3:[movieTitles]
};
console.log(combinedResults);
